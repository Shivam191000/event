import React, { useEffect, useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Calendar, Clock, Bell, Plus, Trash2, Edit2, Filter, Search, Download, Upload, CheckCircle2, Repeat, MapPin, Tag, X, ChevronDown, ChevronUp } from 'lucide-react'

const REPEAT_OPTIONS = ['none', 'daily', 'weekly', 'monthly']

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36)
const toLocalInput = (d) => new Date(d).toISOString().slice(0,16)
const clamp = (n, min, max) => Math.max(min, Math.min(max, n))

const addRepeat = (iso, repeat) => {
  const date = new Date(iso)
  if (repeat === 'daily') date.setDate(date.getDate() + 1)
  else if (repeat === 'weekly') date.setDate(date.getDate() + 7)
  else if (repeat === 'monthly') date.setMonth(date.getMonth() + 1)
  return date.toISOString()
}

const computeNextRemindAt = (event) => {
  const start = new Date(event.datetime).getTime()
  const remindAt = new Date(start - event.offsetMinutes * 60_000)
  return remindAt.toISOString()
}

const isSameDay = (a, b) => {
  const A = new Date(a), B = new Date(b)
  return A.getFullYear() === B.getFullYear() && A.getMonth() === B.getMonth() && A.getDate() === B.getDate()
}

const formatNiceDate = (iso) => {
  const d = new Date(iso)
  return d.toLocaleString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

const downloadText = (filename, text) => {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

const toICS = (event) => {
  const dt = new Date(event.datetime)
  const dtstamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z')
  const dtstart = dt.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z')
  const uidStr = event.id + '@eventreminder.app'
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//EventReminder//EN',
    'BEGIN:VEVENT',
    `UID:${uidStr}`,
    `DTSTAMP:${dtstamp}`,
    `DTSTART:${dtstart}`,
    `SUMMARY:${(event.title || 'Event').replace(/\n/g, ' ')}`,
    event.location ? `LOCATION:${event.location.replace(/\n/g, ' ')}` : null,
    event.description ? `DESCRIPTION:${event.description.replace(/\n/g, ' ')}` : null,
    'END:VEVENT',
    'END:VCALENDAR',
  ].filter(Boolean)
  return lines.join('\r\n')
}

const STORAGE_KEY = 'event-reminder.events.v1'
const loadEvents = () => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]') } catch { return [] }
}
const saveEvents = (events) => { localStorage.setItem(STORAGE_KEY, JSON.stringify(events)) }

const canNotify = () => 'Notification' in window
const requestNotify = async () => {
  if (!canNotify()) return false
  if (Notification.permission === 'granted') return true
  if (Notification.permission === 'denied') return false
  const p = await Notification.requestPermission()
  return p === 'granted'
}
const fireNotification = (event) => {
  try {
    new Notification(event.title || 'Event Reminder', {
      body: `${formatNiceDate(event.datetime)}${event.location ? ' • ' + event.location : ''}${event.category ? ' • ' + event.category : ''}`,
      icon: undefined,
      tag: event.id,
      requireInteraction: false,
    })
  } catch {}
}

export default function App(){
  const [events, setEvents] = useState(() => loadEvents())
  const [query, setQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('upcoming')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [expanded, setExpanded] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)

  const categories = useMemo(() => {
    const s = new Set(events.map(e => e.category).filter(Boolean))
    return ['all', ...Array.from(s)]
  }, [events])

  useEffect(() => { saveEvents(events) }, [events])

  useEffect(() => {
    let cancelled = False
  }, [])

  // Scheduler
  useEffect(() => {
    let cancelled = false
    const tick = async () => {
      const permitted = await requestNotify()
      const now = Date.now()
      setEvents(prev => prev.map(ev => {
        const due = new Date(ev.nextRemindAt).getTime() <= now && !ev.done
        const last = ev.lastNotifiedAt ? new Date(ev.lastNotifiedAt).getTime() : 0
        const sameSlot = Math.abs(new Date(ev.nextRemindAt).getTime() - last) < 1000
        if (permitted && due && !sameSlot) {
          fireNotification(ev)
          const updated = { ...ev, lastNotifiedAt: ev.nextRemindAt }
          if (ev.repeat !== 'none') {
            const nextStart = addRepeat(ev.datetime, ev.repeat)
            const next = new Date(new Date(nextStart).getTime() - ev.offsetMinutes * 60_000).toISOString()
            updated.datetime = nextStart
            updated.nextRemindAt = next
          }
          return updated
        }
        return ev
      }))
      if (!cancelled) setTimeout(tick, 30_000)
    }
    const t = setTimeout(tick, 1000)
    return () => { cancelled = true; clearTimeout(t) }
  }, [])

  const viewEvents = useMemo(() => {
    const now = Date.now()
    return [...events]
      .filter(e => !query || [e.title, e.description, e.location, e.category].filter(Boolean).some(v => v.toLowerCase().includes(query.toLowerCase())))
      .filter(e => categoryFilter === 'all' || e.category === categoryFilter)
      .filter(e => {
        if (!fromDate && !toDate) return True
        const t = new Date(e.datetime).getTime()
        if (fromDate && t < new Date(fromDate).getTime()) return false
        if (toDate) {
          const end = new Date(toDate)
          end.setHours(23,59,59,999)
          if (t > end.getTime()) return false
        }
        return true
      })
      .filter(e => {
        const t = new Date(e.datetime).getTime()
        if (statusFilter === 'upcoming') return t >= now && !e.done
        if (statusFilter === 'past') return t < now
        if (statusFilter === 'done') return e.done
        return true
      })
      .sort((a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime())
  }, [events, query, categoryFilter, fromDate, toDate, statusFilter])

  const openNew = () => { setEditing(null); setShowForm(true) }
  const openEdit = (ev) => { setEditing(ev); setShowForm(true) }
  const remove = (id) => setEvents(prev => prev.filter(e => e.id !== id))
  const toggleDone = (id) => setEvents(prev => prev.map(e => e.id === id ? { ...e, done: !e.done } : e))

  const upsertEvent = (payload) => {
    setEvents(prev => {
      const base = {
        id: uid(),
        createdAt: new Date().toISOString(),
        done: false,
        ...payload,
      }
      const toStore = { ...base, nextRemindAt: computeNextRemindAt(base) }
      if (payload.id) {
        return prev.map(e => e.id === payload.id ? toStore : e)
      }
      return [...prev, toStore]
    })
    setShowForm(false)
  }

  const exportAllJSON = () => downloadText(`events-${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(events, null, 2))
  const exportAllICS = () => {
    const icsAll = events.map(e => toICS(e)).join('\r\n')
    downloadText('events.ics', icsAll)
  }
  const importJSON = (file) => {
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result))
        if (!Array.isArray(data)) throw new Error('Invalid file')
        const cleaned = data.map((e) => ({
          id: e.id || uid(),
          title: String(e.title||'Untitled'),
          description: e.description ? String(e.description) : '',
          location: e.location ? String(e.location) : '',
          category: e.category ? String(e.category) : '',
          datetime: new Date(e.datetime).toISOString(),
          offsetMinutes: clamp(Number(e.offsetMinutes)||0, 0, 525600),
          nextRemindAt: e.nextRemindAt ? new Date(e.nextRemindAt).toISOString() : computeNextRemindAt(e),
          repeat: REPEAT_OPTIONS.includes(e.repeat) ? e.repeat : 'none',
          done: !!e.done,
          createdAt: e.createdAt ? new Date(e.createdAt).toISOString() : new Date().toISOString(),
          lastNotifiedAt: e.lastNotifiedAt ? new Date(e.lastNotifiedAt).toISOString() : undefined,
        }))
        setEvents(cleaned)
      } catch (err) { alert('Import failed: ' + err.message) }
    }
    reader.readAsText(file)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 text-slate-800">
      <header className="sticky top-0 z-20 bg-white/70 backdrop-blur border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <Calendar className="w-6 h-6" />
          <h1 className="text-xl md:text-2xl font-semibold">Event Reminder</h1>
          <span className="ml-auto flex gap-2">
            <button onClick={() => { setEditing(null); setShowForm(true) }} className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-slate-900 text-white shadow hover:bg-slate-800 active:scale-[.98]">
              <Plus className="w-4 h-4" /> New Event
            </button>
            <button onClick={exportAllJSON} className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-slate-100 hover:bg-slate-200 border">
              <Download className="w-4 h-4" /> JSON
            </button>
            <button onClick={exportAllICS} className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-slate-100 hover:bg-slate-200 border">
              <Download className="w-4 h-4" /> ICS
            </button>
            <label className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-slate-100 hover:bg-slate-200 border cursor-pointer">
              <Upload className="w-4 h-4" /> Import
              <input type="file" accept="application/json" className="hidden" onChange={(e)=> e.target.files?.[0] && importJSON(e.target.files[0])} />
            </label>
          </span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3.5" />
            <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search title, desc, location…" className="w-full pl-9 pr-3 py-2 rounded-xl border bg-white"/>
          </div>
          <div className="flex gap-2">
            <span className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border bg-white">
              <Tag className="w-4 h-4"/>
              <select value={categoryFilter} onChange={(e)=>setCategoryFilter(e.target.value)} className="bg-transparent outline-none">
                {categories.map(c=> <option key={c} value={c}>{c}</option>)}
              </select>
            </span>
            <span className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border bg-white">
              <Filter className="w-4 h-4"/>
              <select value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} className="bg-transparent outline-none">
                <option value="upcoming">Upcoming</option>
                <option value="past">Past</option>
                <option value="done">Done</option>
                <option value="all">All</option>
              </select>
            </span>
          </div>
          <input type="date" value={fromDate} onChange={(e)=>setFromDate(e.target.value)} className="px-3 py-2 rounded-xl border bg-white"/>
          <input type="date" value={toDate} onChange={(e)=>setToDate(e.target.value)} className="px-3 py-2 rounded-xl border bg-white"/>
        </div>

        <div className="mt-3">
          <button onClick={()=>setExpanded(v=>!v)} className="text-sm text-slate-600 inline-flex items-center gap-1">
            {expanded ? <ChevronUp className="w-4 h-4"/> : <ChevronDown className="w-4 h-4"/>}
            Tips for best results
          </button>
          <AnimatePresence>
            {expanded && (
              <motion.div initial={{height:0, opacity:0}} animate={{height:'auto', opacity:1}} exit={{height:0, opacity:0}} className="overflow-hidden">
                <ul className="text-sm text-slate-600 bg-white/70 border rounded-xl p-3 mt-2 grid md:grid-cols-2 gap-2">
                  <li>💡 Allow notifications when prompted so reminders can pop up.</li>
                  <li>⏰ Set a reminder offset (e.g., 10–30 minutes before start).</li>
                  <li>🔁 Use repeat for daily/weekly/monthly schedules.</li>
                  <li>💾 Your data is stored locally in your browser.</li>
                </ul>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-4 pb-20">
        {viewEvents.length === 0 ? (
          <div className="mt-10 text-center text-slate-500">
            <Bell className="w-12 h-12 mx-auto mb-2"/>
            <p className="text-lg">No events match your filters. Add one!</p>
            <button onClick={() => { setEditing(null); setShowForm(True) }} className="mt-3 inline-flex items-center gap-2 rounded-2xl px-4 py-2 bg-slate-900 text-white shadow">
              <Plus className="w-4 h-4"/> Create Event
            </button>
          </div>
        ) : (
          <ul className="grid gap-3">
            {viewEvents.map(ev => {
              const now = Date.now()
              const eventTs = new Date(ev.datetime).getTime()
              const remindTs = new Date(ev.nextRemindAt).getTime()
              const isOverdue = remindTs < now && !ev.done
              const isToday = isSameDay(ev.datetime, new Date())
              return (
                <li key={ev.id} className={\`rounded-2xl border bg-white p-4 shadow-sm \${isOverdue ? 'ring-2 ring-rose-300' : ''}\`}>
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex-1 min-w-[220px]">
                      <div className="flex items-center gap-2">
                        <h3 className={\`text-lg font-semibold \${ev.done ? 'line-through text-slate-400' : ''}\`}>{ev.title}</h3>
                        {ev.repeat !== 'none' && (
                          <span title="Repeating" className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-slate-100 border">
                            <Repeat className="w-3 h-3"/> {ev.repeat}
                          </span>
                        )}
                        {ev.category && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 border text-indigo-700">{ev.category}</span>
                        )}
                        {isToday && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-50 border text-emerald-700">Today</span>
                        )}
                      </div>
                      <div className="mt-1 text-sm text-slate-600 flex flex-wrap items-center gap-3">
                        <span className="inline-flex items-center gap-1"><Clock className="w-4 h-4"/>{formatNiceDate(ev.datetime)}</span>
                        <span className="inline-flex items-center gap-1"><Bell className="w-4 h-4"/>Reminds {formatNiceDate(ev.nextRemindAt)}</span>
                        {ev.location && <span className="inline-flex items-center gap-1"><MapPin className="w-4 h-4"/>{ev.location}</span>}
                      </div>
                      {ev.description && (
                        <p className="mt-2 text-sm text-slate-700 max-w-prose">{ev.description}</p>
                      )}
                    </div>
                    <div className="ml-auto flex items-center gap-2">
                      <button onClick={()=>toggleDone(ev.id)} className={\`inline-flex items-center gap-2 rounded-xl px-3 py-2 border \${ev.done ? 'bg-emerald-50 text-emerald-700' : 'bg-white hover:bg-slate-50'}\`}>
                        <CheckCircle2 className="w-4 h-4"/>{ev.done ? 'Undone' : 'Mark done'}
                      </button>
                      <button onClick={()=>downloadText(\`\${ev.title||'event'}.ics\`, toICS(ev))} className="inline-flex items-center gap-2 rounded-xl px-3 py-2 border bg-white hover:bg-slate-50">
                        <Download className="w-4 h-4"/>ICS
                      </button>
                      <button onClick={()=>openEdit(ev)} className="inline-flex items-center gap-2 rounded-xl px-3 py-2 border bg-white hover:bg-slate-50">
                        <Edit2 className="w-4 h-4"/>Edit
                      </button>
                      <button onClick={()=>remove(ev.id)} className="inline-flex items-center gap-2 rounded-xl px-3 py-2 border bg-white hover:bg-rose-50 text-rose-700">
                        <Trash2 className="w-4 h-4"/>Delete
                      </button>
                    </div>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </main>

      <AnimatePresence>
        {showForm && (
          <EventFormModal key={editing?.id || 'new'} initial={editing} onClose={()=>setShowForm(false)} onSave={upsertEvent} />
        )}
      </AnimatePresence>

      <footer className="fixed bottom-4 right-4">
        <PermissionButton />
      </footer>
    </div>
  )
}

function PermissionButton(){
  const [perm, setPerm] = useState(typeof Notification !== 'undefined' ? Notification.permission : 'default')
  const ask = async () => {
    const ok = await requestNotify()
    setPerm(Notification.permission)
    if (!ok) alert('Notifications are blocked by your browser.')
  }
  if (!canNotify()) return null
  return (
    <button onClick={ask} className="inline-flex items-center gap-2 rounded-full px-4 py-2 bg-slate-900 text-white shadow-lg">
      <Bell className="w-4 h-4"/> {perm === 'granted' ? 'Notifications On' : 'Enable Notifications'}
    </button>
  )
}

function EventFormModal({ initial, onClose, onSave }){
  const [title, setTitle] = useState(initial?.title || '')
  const [description, setDescription] = useState(initial?.description || '')
  const [location, setLocation] = useState(initial?.location || '')
  const [category, setCategory] = useState(initial?.category || '')
  const [datetime, setDatetime] = useState(toLocalInput(initial?.datetime || new Date()))
  const [offsetUnit, setOffsetUnit] = useState('minutes')
  const [offsetValue, setOffsetValue] = useState(10)
  const [repeat, setRepeat] = useState(initial?.repeat || 'none')

  useEffect(()=>{
    if (!initial) return
    try {
      const minutes = Math.max(0, Math.round((new Date(initial.datetime).getTime() - new Date(initial.nextRemindAt).getTime())/60_000))
      if (minutes % (24*60) === 0) { setOffsetUnit('days'); setOffsetValue(minutes/(24*60)) }
      else if (minutes % 60 === 0) { setOffsetUnit('hours'); setOffsetValue(minutes/60) }
      else { setOffsetUnit('minutes'); setOffsetValue(minutes) }
    } catch {}
  }, [initial])

  const overlayRef = useRef(null)
  const closeOnBackdrop = (e) => { if (e.target === overlayRef.current) onClose() }

  const submit = (e) => {
    e.preventDefault()
    if (!title.trim()) return alert('Please enter a title')
    const when = new Date(datetime)
    if (isNaN(when.getTime())) return alert('Please set a valid date & time')
    let minutes = Number(offsetValue)||0
    if (offsetUnit === 'hours') minutes *= 60
    if (offsetUnit === 'days') minutes *= 24*60
    minutes = clamp(minutes, 0, 525600)

    const payload = {
      id: initial?.id,
      title: title.trim(),
      description: description.trim(),
      location: location.trim(),
      category: category.trim(),
      datetime: when.toISOString(),
      offsetMinutes: minutes,
      repeat,
    }
    payload.nextRemindAt = computeNextRemindAt(payload)
    onSave(payload)
  }

  return (
    <motion.div ref={overlayRef} onMouseDown={closeOnBackdrop} className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} exit={{opacity:0, y:20}} className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <h2 className="text-lg font-semibold">{initial ? 'Edit Event' : 'New Event'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-100"><X className="w-5 h-5"/></button>
        </div>
        <form onSubmit={submit} className="p-5 grid gap-4">
          <div className="grid md:grid-cols-2 gap-3">
            <label className="grid gap-1">
              <span className="text-sm text-slate-600">Title</span>
              <input value={title} onChange={(e)=>setTitle(e.target.value)} required placeholder="e.g., Project demo review" className="px-3 py-2 rounded-xl border"/>
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-slate-600">Date & time</span>
              <input type="datetime-local" value={datetime} onChange={(e)=>setDatetime(e.target.value)} required className="px-3 py-2 rounded-xl border"/>
            </label>
          </div>

          <div className="grid md:grid-cols-3 gap-3">
            <label className="grid gap-1">
              <span className="text-sm text-slate-600">Location</span>
              <input value={location} onChange={(e)=>setLocation(e.target.value)} placeholder="e.g., Room 402 or Google Meet" className="px-3 py-2 rounded-xl border"/>
            </label>
            <label className="grid gap-1">
              <span className="text-sm text-slate-600">Category</span>
              <input value={category} onChange={(e)=>setCategory(e.target.value)} placeholder="e.g., College, Work, Personal" className="px-3 py-2 rounded-xl border"/>
            </label>
            <div className="grid grid-cols-[1fr_auto_1fr] gap-2 items-end">
              <label className="grid gap-1">
                <span className="text-sm text-slate-600">Remind me</span>
                <input type="number" min={0} value={offsetValue} onChange={(e)=>setOffsetValue(e.target.value)} className="px-3 py-2 rounded-xl border"/>
              </label>
              <label className="grid gap-1">
                <span className="invisible text-sm">unit</span>
                <select value={offsetUnit} onChange={(e)=>setOffsetUnit(e.target.value)} className="px-3 py-2 rounded-xl border bg-white">
                  <option value="minutes">min</option>
                  <option value="hours">hours</option>
                  <option value="days">days</option>
                </select>
              </label>
              <label className="grid gap-1">
                <span className="text-sm text-slate-600">Repeat</span>
                <select value={repeat} onChange={(e)=>setRepeat(e.target.value)} className="px-3 py-2 rounded-xl border bg-white">
                  {REPEAT_OPTIONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </label>
            </div>
          </div>

          <label className="grid gap-1">
            <span className="text-sm text-slate-600">Description</span>
            <textarea value={description} onChange={(e)=>setDescription(e.target.value)} rows={4} placeholder="Agenda, links, notes…" className="px-3 py-2 rounded-xl border"/>
          </label>

          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="rounded-xl px-4 py-2 border">Cancel</button>
            <button type="submit" className="rounded-xl px-4 py-2 bg-slate-900 text-white">{initial ? 'Save changes' : 'Create event'}</button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  )
}
