# Event Reminder (React + Vite + Tailwind)

A clean event reminder web app with notifications, repeats, filters, and import/export.

## Quick Start

```bash
# 1) Install deps
npm install

# 2) Run dev server
npm run dev

# 3) Build for production
npm run build && npm run preview
```

### Features
- Add / edit / delete events
- Browser notifications (grant permission when prompted)
- Repeats: none / daily / weekly / monthly
- Reminder offset (minutes / hours / days before)
- Search, category + status filters, date range
- Export JSON and ICS (single event or all)
- Import JSON
- LocalStorage persistence

> Note: Reminders fire while the site is open (no service worker in this version).
